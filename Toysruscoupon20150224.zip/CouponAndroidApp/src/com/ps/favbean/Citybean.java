package com.ps.favbean;

public class Citybean {

	
	String  sCityId, sCityName,sCityLat, sCityLong;

	public String getsCityId() {
		return sCityId;
	}

	public void setsCityId(String sCityId) {
		this.sCityId = sCityId;
	}

	public String getsCityName() {
		return sCityName;
	}

	public void setsCityName(String sCityName) {
		this.sCityName = sCityName;
	}

	public String getsCityLat() {
		return sCityLat;
	}

	public void setsCityLat(String sCityLat) {
		this.sCityLat = sCityLat;
	}

	public String getsCityLong() {
		return sCityLong;
	}

	public void setsCityLong(String sCityLong) {
		this.sCityLong = sCityLong;
	}
}
