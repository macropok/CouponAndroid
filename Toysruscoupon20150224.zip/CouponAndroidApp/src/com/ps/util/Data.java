package com.ps.util;

public class Data {

	public static final int DISPLAY_COUPON = 1;
	public static final int GSM = 2;
	public static final int SORT = 3;
	public static final int ADDTOFAV = 4;
	public static final int SEND_MAIL = 5;
	public static final int LIKE = 6;
	public static final int CITY = 7;
	public static final int POLICY = 8;
	
	
	public static final int DIALOG_DOWNLOAD_PROGRESS = 100;
	
	public static final String ID = "id";
	public static final String COUPON_CATEGORY = "c_category";
	public static final String COUPON_NAME = "c_name";
	public static final String FROM_DATE = "c_date";
	public static final String TO_DATE = "to_date";
	public static final String IMAGE_PATH = "c_image";
	public static final String COMMENT = "c_text";
	public static final String SORTBy = "c_kind";
	public static final String AGE = "c_age";
	public static final String TOTAL_LIKE = "total_like";
	public static final String IMAGE_URL = "c_image";
	public static final String COUPON_NUMBER = "coupan_number";
	public static final String COUPON_SHARE_IMAGE = "c_share_image";
	public static String likeValues;
	
	public static  String DEVICE_ID = "";
	public static String DEVICE_NAME = "";
	public static String DEVICE_GCMID = "";
	public static final String DEVICE_TYPE = "Android";
	
	
}
