package com.ps.helper;

public class WebServices {
	//http://toysrsuscoupon.com/webservices/
	/*public static String COUPON_SHABATURL ="http://shabbat.nethost.co.il/webservices/index.php?";
	
	public static String COUPON_URL = "http://toysrsuscoupon.com/webservices/index.php?";
	public static String GCM_URL = "http://toysrsuscoupon.com/webservices/index.php";
	public static String SORT_URL = "http://toysrsuscoupon.com/webservices/index.php";
	public static String MAP_URL = "http://toysrsuscoupon.com/webservices/index.php?";
	public static String LIKE_URL = "http://toysrsuscoupon.com/webservices/index.php";
	public static String CITY_URL = "http://toysrsuscoupon.com/webservices/index.php";
	public static String POLICY_URL = "http://toysrsuscoupon.com/webservices/index.php";*/
	
	
	
	/*public static String COUPON_SHABATURL ="http://toysruscoupon.nethost.co.il/NEWCMS/webservices/index.php?action=getCoupanCount";
	public static String COUPON_STATUS_URL = "http://toysruscoupon.nethost.co.il/NEWCMS/webservices/index.php?action=getCouponsStatus&coupon_ids";
	public static String COUPON_URL = "http://toysruscoupon.nethost.co.il/NEWCMS/webservices/index.php?";
	public static String GCM_URL = "http://toysruscoupon.nethost.co.il/NEWCMS/webservices/index.php";
	public static String SORT_URL = "http://toysruscoupon.nethost.co.il/NEWCMS/webservices/index.php";
	public static String MAP_URL = "http://toysruscoupon.nethost.co.il/NEWCMS/webservices/index.php?";
	public static String LIKE_URL = "http://toysruscoupon.nethost.co.il/NEWCMS/webservices/index.php";
	public static String CITY_URL = "http://toysruscoupon.nethost.co.il/NEWCMS/webservices/index.php";
	public static String POLICY_URL = "http://toysruscoupon.nethost.co.il/NEWCMS/webservices/index.php";*/
	
	
	
	/*public static String COUPON_COUNT_URL ="http://192.168.1.25/toysruscoupon/webservices/index.php?action=getCoupanCount&category=0";
	public static String COUPON_STATUS_URL = "http://192.168.1.25/toysruscoupon/webservices/index.php?action=getCouponsStatus&coupon_ids";
	public static String COUPON_URL = "http://192.168.1.25/toysruscoupon/webservices/index.php?";
	public static String GCM_URL = "http://192.168.1.25/toysruscoupon/webservices/index.php";
	public static String SORT_URL = "http://192.168.1.25/toysruscoupon/webservices/index.php";
	public static String MAP_URL = "http://192.168.1.25/toysruscoupon/webservices/index.php?";
	public static String LIKE_URL = "http://192.168.1.25/toysruscoupon/webservices/index.php";
	public static String CITY_URL = "http://192.168.1.25/toysruscoupon/webservices/index.php";
	public static String POLICY_URL = "http://192.168.1.25/toysruscoupon/webservices/index.php";*/
	
	
	public static String COUPON_COUNT_URL ="http://toysruscoupon.nethost.co.il/NEWCMS/webservices/index.php?action=getCoupanCount&category=0";
	public static String COUPON_STATUS_URL = "http://toysruscoupon.nethost.co.il/NEWCMS/webservices/index.php?action=getCouponsStatus&coupon_ids";
	public static String COUPON_URL = "http://toysruscoupon.nethost.co.il/NEWCMS/webservices/index.php?";
	public static String GCM_URL = "http://toysruscoupon.nethost.co.il/NEWCMS/webservices/index.php";
	public static String SORT_URL = "http://toysruscoupon.nethost.co.il/NEWCMS/webservices/index.php";
	public static String MAP_URL = "http://toysruscoupon.nethost.co.il/NEWCMS/webservices/index.php?";
	public static String LIKE_URL = "http://toysruscoupon.nethost.co.il/NEWCMS/webservices/index.php";
	public static String CITY_URL = "http://toysruscoupon.nethost.co.il/NEWCMS/webservices/index.php";
	public static String POLICY_URL = "http://toysruscoupon.nethost.co.il/NEWCMS/webservices/index.php";
	
}
